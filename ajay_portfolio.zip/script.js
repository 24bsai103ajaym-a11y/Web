function handleSend(e){
  e.preventDefault();
  const form = e.target;
  const name = form.name.value.trim();
  const email = form.email.value.trim();
  const phone = form.phone.value.trim();
  const message = form.message.value.trim();

  alert(`Message sent!\n\nName: ${name}\nEmail: ${email}\nPhone: ${phone}\n\nWe'll get back to you soon.`);
  form.message.value = "";
  return false;
}